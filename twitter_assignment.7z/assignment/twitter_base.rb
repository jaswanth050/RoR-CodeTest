require "oauth"
require "uri"
require "json"
require "net/https"

require "./parse_tweet"
require "./twitter_stream"

twitter_stream = TwitterStream.new()
parse_tweet = ParseTweet.new(twitter_stream)

p parse_tweet.parse	