require "json"

class ParseTweet

	def initialize(twitter_obj)
		@twitter_obj = twitter_obj
	end	

	def parse
		while success = @twitter_obj.auth
			puts "Time |  name | Tweet " 
			@twitter_obj.buffer do |stream_data|
			    begin
			    	data = JSON.parse(stream_data)
			    	puts "#{data['created_at']} | #{data['user']['name']} | #{data['text']}" if data['text']
			    rescue Exception => e
			      next	
			    end

			end    
		end	  
	end	



end	