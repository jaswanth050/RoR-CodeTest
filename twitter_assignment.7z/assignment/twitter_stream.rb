
class TwitterStream

	URL = "https://stream.twitter.com/1.1/statuses/filter.json?track=technology"
	BASE_URL = "https://twitter.com"

	CREDITALS = { 
		key: "DUMMY_KEY", 
		secret: "DUMMY_SECRET",
		token: "DUMMY_TOKEN", 
		token_secret: "DUMMY_TOKEN_SECRET" 
	}


	attr_accessor :client, :request

	def auth		
		uri = URI.parse(URL)

		@client = Net::HTTP.new(uri.host, uri.port)
	    @client.use_ssl = true
	    @client.verify_mode = OpenSSL::SSL::VERIFY_PEER
	    
	    @request = Net::HTTP::Get.new( uri.request_uri, "Accept-Encoding" => "identity")
	    oauth_consumer = OAuth::Consumer.new( CREDITALS[:key], CREDITALS[:secret], site: BASE_URL)
	    oauth_token = OAuth::AccessToken.new( oauth_consumer, CREDITALS[:token], CREDITALS[:token_secret])
	    @request.oauth!(@client, oauth_consumer, oauth_token)
	end	

	 def buffer(&block)
	    @client.start do |http|

	      http.request(@request) do |response|
	        response.read_body(&block) 
	      end
	    end
	    self
	 end

end	

